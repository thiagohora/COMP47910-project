/*
-- Query: select * from credit_cards
LIMIT 0, 1000

-- Date: 2023-07-16 18:56
*/
INSERT INTO `` (`id`,`user_id`,`card_name`,`card_number`,`expiration_date`,`last_four_digits`) VALUES (1,5,'James Smith','fT/xlEEYZ4cTyXbFx1etw3FbqcfZB99ZRHyCpEoIC7g=','bG22/yk4lzrixZbADcMDkg==','6578');
INSERT INTO `` (`id`,`user_id`,`card_name`,`card_number`,`expiration_date`,`last_four_digits`) VALUES (2,6,'G A Ginelli','I2z9NfK6HcuYszGPSabtItxy1WyZgFSHmub3y1ubw5Y=','kla9SN+k5sjHQ9uoF62cjw==','8765');
INSERT INTO `` (`id`,`user_id`,`card_name`,`card_number`,`expiration_date`,`last_four_digits`) VALUES (3,7,'Robertino Smith','rWIilQPMa9zcSIJQGH00CTUPDNKtOfH6pTX0ts5mYXA=','ulKZpeB3zj5C4FCnf/QEaA==','0987');
INSERT INTO `` (`id`,`user_id`,`card_name`,`card_number`,`expiration_date`,`last_four_digits`) VALUES (4,8,'Maria Garcia','VrutKDlWSRn5RFq/dpJBhc0BH6JqAIWo1+8Yt3lQkzc=','9PlGdSHwUJa6/atN+EQz8w==','2123');
