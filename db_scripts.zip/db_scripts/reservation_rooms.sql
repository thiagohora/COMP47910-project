/*
-- Query: select * from reservation_rooms
LIMIT 0, 1000

-- Date: 2023-07-16 18:58
*/
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (5,1);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (6,1);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (11,1);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (12,1);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (7,2);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (13,2);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (14,2);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (15,2);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (16,2);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (10,3);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (8,4);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (17,4);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (18,4);
INSERT INTO `` (`reservation_id`,`room_id`) VALUES (9,5);
